# GroundWork STAC Export

This directory contains a [STAC](https://stacspec.org/) export of data from GroundWork.

It's organized into two separate STAC [collections](https://github.com/radiantearth/stac-spec/blob/master/collection-spec/collection-spec.md), one for imagery and one for labels.

The collections each contain an [item](https://github.com/radiantearth/stac-spec/blob/master/item-spec/item-spec.md)
for every image in the GroundWork campaign that you created this export for.

| Image Name | Labels Path | Imagery Path |
| :--------- | ----------- | ------------ |
| jacksonville.sub | labels/5fcd1e3f-4ff3-430d-9078-b6dac3b00db8.json | images/948022f3-29a5-43d1-9370-73e806eec8a3.json |

Imagery items in this export contain [TMS](https://en.wikipedia.org/wiki/Tile_Map_Service) URLs. You can put those
TMS URLs into tools like [geojson.io](http://geojson.io/#map=2/20.0/0.0) (via "Meta" -> "Add map layer") or QGIS (via
"XYZ Tiles") to view them.

Label items in this export contain a `data` asset pointing to a GeoJSON file of the labels
that they contain. You can view this GeoJSON file in QGIS by dragging it into the workspace.
They also include links to their imagery -- you can find the imagery link for a label item in the
array element of its `links` property with the property `"rel": "source"`. That link refers to the imagery item with
the TMS URL(s) that match what was visible in GroundWork while these labels were being created.

The ecosystem for consuming STACs for different purposes is to this point a bit underdeveloped. Some tools you might
be interested in are:

- [Franklin](https://github.com/azavea/franklin) for bringing up a web server for your STAC
- [PySTAC](https://github.com/stac-utils/pystac) for reading and manipulating the STAC

If there's something specific you'd like to be able to do with your STAC export or that you've done that you'd like
to tell us about, please contact us with the chat in GroundWork or [by email](mailto:groundwork@azavea.com).
